<?php
/**
 * Template for displaying single posts
 * 
 * @package NCLLC_Pro
 */

get_header(); ?>

<main id="main-content" class="site-main">
    <?php
    while (have_posts()) :
        the_post();
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="container">
                <header class="entry-header" style="padding: 6rem 0 2rem; text-align: center;">
                    <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
                    
                    <div class="entry-meta" style="color: #6b7280; margin-top: 1rem;">
                        <span class="posted-on">
                            <?php echo get_the_date(); ?>
                        </span>
                        <span class="byline" style="margin-left: 1rem;">
                            by <?php the_author(); ?>
                        </span>
                    </div>
                </header>

                <?php if (has_post_thumbnail()) : ?>
                    <div class="post-thumbnail" style="margin: 2rem 0;">
                        <?php the_post_thumbnail('large', array('style' => 'width: 100%; height: auto; border-radius: 1rem;')); ?>
                    </div>
                <?php endif; ?>

                <div class="entry-content" style="padding: 2rem 0 4rem; max-width: 800px; margin: 0 auto; line-height: 1.8;">
                    <?php
                    the_content();

                    wp_link_pages(array(
                        'before' => '<div class="page-links">' . esc_html__('Pages:', 'ncllc-pro'),
                        'after'  => '</div>',
                    ));
                    ?>
                </div>

                <footer class="entry-footer" style="padding: 2rem 0; border-top: 1px solid #e5e7eb; max-width: 800px; margin: 0 auto;">
                    <?php
                    $categories_list = get_the_category_list(', ');
                    if ($categories_list) {
                        printf('<span class="cat-links">Categories: %s</span>', $categories_list);
                    }

                    $tags_list = get_the_tag_list('', ', ');
                    if ($tags_list) {
                        printf('<span class="tags-links" style="margin-left: 1rem;">Tags: %s</span>', $tags_list);
                    }
                    ?>
                </footer>
            </div>
        </article>

        <?php
        // Post navigation
        the_post_navigation(array(
            'prev_text' => '<span class="nav-subtitle">Previous:</span> <span class="nav-title">%title</span>',
            'next_text' => '<span class="nav-subtitle">Next:</span> <span class="nav-title">%title</span>',
        ));

        // Comments
        if (comments_open() || get_comments_number()) :
            comments_template();
        endif;

    endwhile;
    ?>
</main>

<?php get_footer(); ?>
