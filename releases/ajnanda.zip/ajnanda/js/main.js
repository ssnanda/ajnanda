/**
 * AJNanda Theme JavaScript
 * Minimal frontend behavior only.
 */

(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.getElementById('mobile-menu-toggle');
        const navMenu = document.querySelector('.nav-menu');

        if (menuToggle && navMenu) {
            menuToggle.addEventListener('click', function () {
                const isOpen = menuToggle.classList.toggle('active');

                navMenu.classList.toggle('mobile-active', isOpen);
                document.body.classList.toggle('menu-open', isOpen);
                menuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            });

            document.addEventListener('click', function (event) {
                const clickedInsideMenu = event.target.closest('.main-navigation');
                const clickedToggle = event.target.closest('#mobile-menu-toggle');

                if (!clickedInsideMenu && !clickedToggle) {
                    menuToggle.classList.remove('active');
                    navMenu.classList.remove('mobile-active');
                    document.body.classList.remove('menu-open');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            });
        }

        document.querySelectorAll('a[href^="#"]').forEach(function (link) {
            link.addEventListener('click', function (event) {
                const targetId = link.getAttribute('href');

                if (!targetId || targetId === '#') {
                    return;
                }

                const target = document.querySelector(targetId);

                if (!target) {
                    return;
                }

                event.preventDefault();

                const headerOffset = 80;
                const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            });
        });

        const scrollTopButton = document.createElement('button');
        scrollTopButton.className = 'scroll-to-top';
        scrollTopButton.type = 'button';
        scrollTopButton.setAttribute('aria-label', 'Scroll to top');
        scrollTopButton.textContent = '↑';
        document.body.appendChild(scrollTopButton);

        window.addEventListener('scroll', function () {
            scrollTopButton.classList.toggle('visible', window.scrollY > 300);
        }, { passive: true });

        scrollTopButton.addEventListener('click', function () {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    });
})();
